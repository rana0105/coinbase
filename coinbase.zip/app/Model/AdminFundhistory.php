<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AdminFundhistory extends Model
{
    protected $fillable = ['adminamount'];
}
